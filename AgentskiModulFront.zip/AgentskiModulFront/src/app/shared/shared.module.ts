import { NgModule } from '@angular/core';
//import { LoggedInComponent } from './main/loggedIn/loggedIn.component';
@NgModule({
  imports: [
    

  ],
  exports:[
  
  ],
  providers: [
    
    
],
})
export class SharedModule { }
