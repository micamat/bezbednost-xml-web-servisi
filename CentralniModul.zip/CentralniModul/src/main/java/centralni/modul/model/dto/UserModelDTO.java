package centralni.modul.model.dto;

public class UserModelDTO {

}
